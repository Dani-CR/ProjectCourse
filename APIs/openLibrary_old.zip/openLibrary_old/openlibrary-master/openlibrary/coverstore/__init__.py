"""Image store to store book covers and author photos for the Open Library.
"""
