"""
Open Library plugin.
"""
