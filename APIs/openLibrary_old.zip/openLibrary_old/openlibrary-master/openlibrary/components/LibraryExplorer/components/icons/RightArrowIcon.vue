<template>
  <svg
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:cc="http://creativecommons.org/ns#"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:svg="http://www.w3.org/2000/svg"
    xmlns="http://www.w3.org/2000/svg"
    version="1.1"
    viewBox="0 0 4.2742091 4.2333331"
    height="15.999999"
    width="16.15449"
  >
    <path
      d="M 1.2009987,0.24999936 3.0732206,2.1270903 1.2217989,3.9833339"
      style="fill:none;stroke:currentColor;stroke-width:.5;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4"
    ></path>
  </svg>
</template>
