<template>
  <svg
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:cc="http://creativecommons.org/ns#"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:svg="http://www.w3.org/2000/svg"
    xmlns="http://www.w3.org/2000/svg"
    width="16"
    height="16"
    viewBox="0 0 4.2742091 4.2333331"
    version="1.1"
  >
    <path
      d="M 2.9951642,0.83271585 V 3.1419466 M 2.1750393,1.6267067 3.0082368,0.79350925 3.8352594,1.6267067"
      style="stroke: currentColor; stroke-width: 0.4; fill: none; stroke-linecap:round;stroke-linejoin:round;"
    ></path>
    <path
      d="M 1.2440267,3.4398244 V 1.1305936 M 2.0641516,2.6458335 1.2309541,3.479031 0.4039315,2.6458335"
      style="stroke: currentColor; stroke-width: 0.4; fill: none; stroke-linecap:round;stroke-linejoin:round;"
    ></path>
  </svg>
</template>
