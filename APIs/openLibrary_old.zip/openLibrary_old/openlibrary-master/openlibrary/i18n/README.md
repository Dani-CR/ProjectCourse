# i18n Contributor's Guide

This page has moved to the wiki: https://github.com/internetarchive/openlibrary/wiki/Internationalization
