"""Core functionality of Open Library.

This is a set of reusable, easily testable modules.
"""
