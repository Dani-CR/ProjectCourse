"""Admin web interface
"""
