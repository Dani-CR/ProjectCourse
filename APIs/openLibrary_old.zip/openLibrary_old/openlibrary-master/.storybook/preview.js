
export const parameters = {
  actions: { argTypesRegex: "^on[A-Z].*" },
}