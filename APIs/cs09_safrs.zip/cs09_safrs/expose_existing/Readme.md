# Exposing existing databases

example:

```
python3 expose_existing.py mysql+pymysql://root:password@localhost/sakila --host 172.16.17.11 --port 5555
```

Documentation in the [wiki](https://github.com/thomaxxl/safrs/wiki/Exposing-Existing-Databases)

