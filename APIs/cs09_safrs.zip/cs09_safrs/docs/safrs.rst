.. currentmodule:: safrs
.. automodule:: safrs
    :members:

SAFRS
======
