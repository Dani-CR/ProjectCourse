.. automodule:: safrs.api_methods
    :members:

API methods
===========

