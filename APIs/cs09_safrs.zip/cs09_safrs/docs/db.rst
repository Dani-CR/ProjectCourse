.. automodule:: safrs.db
    :members:

