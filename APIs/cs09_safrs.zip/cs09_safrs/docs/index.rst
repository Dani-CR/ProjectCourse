.. safrs documentation master file, created by
   sphinx-quickstart on Thu Sep 21 14:00:19 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to safrs's documentation!
=================================


.. toctree::
   :maxdepth: 2
   :caption: Table of Contents

   safrs
   api_methods

Check https://github.com/thomaxxl/safrs/blob/master/README.md

Indices and tables
==================

* :ref:`modindex`
* :ref:`genindex`
* :ref:`search`

