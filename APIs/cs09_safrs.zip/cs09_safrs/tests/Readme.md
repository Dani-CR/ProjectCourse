
Testing is done with the docker image in https://github.com/thomaxxl/safrs-example


