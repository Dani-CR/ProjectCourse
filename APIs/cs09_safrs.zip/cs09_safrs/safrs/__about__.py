__version__ = "2.10.4"
__description__ = "Self-documenting(OAS) JSON:API framework for flask"
